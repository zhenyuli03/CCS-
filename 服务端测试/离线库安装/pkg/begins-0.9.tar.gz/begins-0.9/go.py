import begin
import pdb; pdb.set_trace()
def f():
    pass
g = begin.logging(f)
c = begin.convert(_automatic=True)
h = c(g)
