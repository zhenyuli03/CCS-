import begin
@begin.start
def run(name: 'What, is your name?',
        quest: 'What, is your quest?',
        colour: 'What, is your favourite colour?'):
    pass
