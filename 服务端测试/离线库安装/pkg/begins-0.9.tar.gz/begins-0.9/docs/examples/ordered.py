import begin

@begin.start(short_args=False, lexical_order=True)
def main(charlie=3, alpha=1, beta=2):
    pass
