import begin
@begin.start
def main():
    "not much of a program"
