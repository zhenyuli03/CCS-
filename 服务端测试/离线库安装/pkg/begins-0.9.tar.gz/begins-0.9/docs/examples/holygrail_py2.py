import begin
@begin.start
def run(name='Arther', quest='Holy Grail', colour='blue', *knights):
    "tis but a scratch!"
