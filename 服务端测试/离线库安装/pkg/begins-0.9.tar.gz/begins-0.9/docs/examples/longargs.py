import begin
@begin.start(short_args=False)
def run(name='Arther', quest='Holy Grail', colour='blue', *knights):
    "tis but a scratch!"
