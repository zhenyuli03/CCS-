from __future__ import absolute_import, division, print_function

import logging
import sys

logging.raiseExceptions = 0
